

geometry: unit square
boundary: leftright_Diri_other_Neum
refinement: global
solution: (c^(-1)*(x-0.5))^2+(c^(-1)*(y-0.5))^2
scaling? no
