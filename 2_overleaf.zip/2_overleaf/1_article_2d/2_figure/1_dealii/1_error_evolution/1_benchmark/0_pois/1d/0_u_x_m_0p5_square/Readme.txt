
all dirichlet boundaries
