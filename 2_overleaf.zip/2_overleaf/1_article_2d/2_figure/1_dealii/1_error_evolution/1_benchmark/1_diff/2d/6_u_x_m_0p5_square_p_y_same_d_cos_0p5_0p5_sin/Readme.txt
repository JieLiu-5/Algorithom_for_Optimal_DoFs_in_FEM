
D = [cos(pi(x+y)) 0.5; 0.5 sin(pi(x+y))]
