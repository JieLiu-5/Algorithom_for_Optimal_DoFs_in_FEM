
D = [1+x+y xy; xy 1+x+y]
