
All dirichlet boundaries
