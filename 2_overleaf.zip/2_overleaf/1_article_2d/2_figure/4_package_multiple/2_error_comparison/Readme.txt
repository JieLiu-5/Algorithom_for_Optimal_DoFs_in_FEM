
applied to

u=exp(-(x-0.5)^2)
element degree: 5 when using the std FEM
unit square
global refinement
no scaling 
absolute error
