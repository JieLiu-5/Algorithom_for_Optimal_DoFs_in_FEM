# settings_fig.py

vec_marker=['o','d','^','s','*', 'h', '+', 'x', '|', '_']
vec_markeredgecolor=['k', 'b', 'r', 'c', 'm', 'y', 'g', 'w']
vec_markerfacecolor = ["none","none","none","none","none","none","none","none"]
size_marker=8


fontsize_label = 20
fontsize_tick = 18
fontsize_legend = 18
id_loc_legend = 1
